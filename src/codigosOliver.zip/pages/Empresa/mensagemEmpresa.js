import React from 'react-native'
import {Text} from 'react-native'
import { Background, Container } from '../Login/styles';

export default function MensagemEmpresa(){
    return(
        <Background>
            <Container>
                
            </Container>
        </Background>
    )
}